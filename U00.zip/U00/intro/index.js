// javascript
document.getElementById("clickable").addEventListener("click", myFunction);

function myFunction() {
  document.getElementById("clickable").innerHTML = "YOU CLICKED ME!";
}
